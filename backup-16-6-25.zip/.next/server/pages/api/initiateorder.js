"use strict";(()=>{var e={};e.id=2366,e.ids=[2366],e.modules={3498:e=>{e.exports=require("mysql2/promise")},5600:e=>{e.exports=require("next/dist/compiled/next-server/pages-api.runtime.prod.js")},6762:(e,r)=>{Object.defineProperty(r,"M",{enumerable:!0,get:function(){return function e(r,t){return t in r?r[t]:"then"in r&&"function"==typeof r.then?r.then(r=>e(r,t)):"function"==typeof r&&"default"===t?r:void 0}}})},5413:(e,r,t)=>{t.r(r),t.d(r,{config:()=>l,default:()=>d,routeModule:()=>A});var s={};t.r(s),t.d(s,{default:()=>u});var n=t(9947),o=t(2706),i=t(6762),a=t(7856),p=t(3498),c=t.n(p);async function u(e,r){if("POST"!==e.method)return r.status(405).json({message:"Method not allowed"});let{name:t,email:s,phone:n,company:o,subject:i,product:p,package:u,billing:d,quantity:l,total:A,licenseType:m,cores:P,productId:f}=e.body;try{await a.Z.sendMail({...a.M,subject:`New Order: ${p}`,text:`New order received for ${p}`,html:`
        <h1>New Order Received</h1>
        <h2>Customer Details</h2>
        <p>Name: ${t}</p>
        <p>Email: ${s}</p>
        <p>Phone: ${n}</p>
        <p>Company: ${o}</p>
        
        <h2>Order Details</h2>
        <p>Product: ${p}</p>
        <p>Package: ${u}</p>
        ${m?`<p>License Type: ${m}</p>`:""}
        ${P?`<p>Cores: ${P}</p>`:""}
        <p>Billing Option: ${d}</p>
        <p>Quantity: ${l}</p>
        <p>Total Price: ₹${A.toLocaleString()}</p>
        <p>Order Time: ${new Date().toLocaleString()}</p>
      `});let e=await c().createConnection({host:process.env.DB_HOST,port:process.env.DATABASE_PORT,user:process.env.DB_USER,password:process.env.DB_PASSWORD,database:process.env.DB_NAME,ssl:"true"===process.env.DATABASE_SSL}),v=`
      INSERT INTO initiated_orders 
      (name, email, phone, company, subject, product, package, billing, quantity, total, license_type, cores, product_id)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `,E=[t,s,n,o,i,p,u,d,l,A,m||"NA",P||"NA",f||"NA"];return await e.execute(v,E),await e.end(),r.status(200).json({message:"Order submitted successfully!"})}catch(e){return console.error("Error processing order:",e),r.status(500).json({message:"Failed to process order"})}}let d=(0,i.M)(s,"default"),l=(0,i.M)(s,"config"),A=new n.PagesAPIRouteModule({definition:{kind:o.A.PAGES_API,page:"/api/initiateorder",pathname:"/api/initiateorder",bundlePath:"",filename:""},userland:s})},7856:(e,r,t)=>{t.d(r,{M:()=>l,Z:()=>d});let s=require("dotenv");var n=t.n(s);let o=require("nodemailer");var i=t.n(o);n().config();let a=process.env.WEBMAIL_HOST,p=Number(process.env.WEBMAIL_PORT),c=process.env.WEBMAIL_USER,u=process.env.WEBMAIL_PASS;if(!a||!p||!c||!u)throw Error("Missing required environment variables for email configuration");let d=i().createTransport({host:a,port:p,secure:465===p,auth:{user:c,pass:u}}),l={from:c,to:"sales@sixthstar.in",cc:["wm.seo@sixthstar.in","sales2sixthstar@gmail.com"]}},2706:(e,r)=>{Object.defineProperty(r,"A",{enumerable:!0,get:function(){return t}});var t=function(e){return e.PAGES="PAGES",e.PAGES_API="PAGES_API",e.APP_PAGE="APP_PAGE",e.APP_ROUTE="APP_ROUTE",e.IMAGE="IMAGE",e}({})},9947:(e,r,t)=>{e.exports=t(5600)}};var r=require("../../webpack-api-runtime.js");r.C(e);var t=r(r.s=5413);module.exports=t})();