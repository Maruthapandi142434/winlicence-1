"use strict";(()=>{var e={};e.id=5217,e.ids=[5217],e.modules={3498:e=>{e.exports=require("mysql2/promise")},5600:e=>{e.exports=require("next/dist/compiled/next-server/pages-api.runtime.prod.js")},6762:(e,t)=>{Object.defineProperty(t,"M",{enumerable:!0,get:function(){return function e(t,r){return r in t?t[r]:"then"in t&&"function"==typeof t.then?t.then(t=>e(t,r)):"function"==typeof t&&"default"===r?t:void 0}}})},7722:(e,t,r)=>{r.r(t),r.d(t,{config:()=>d,default:()=>p,routeModule:()=>g});var n={};r.r(n),r.d(n,{default:()=>c});var s=r(9947),i=r(2706),o=r(6762),a=r(3498),u=r.n(a);async function c(e,t){if("GET"!==e.method)return t.status(405).json({message:"Method not allowed"});try{let e=await u().createConnection({host:process.env.DB_HOST,port:process.env.DATABASE_PORT,database:process.env.DB_NAME,user:process.env.DB_USER,password:process.env.DB_PASSWORD,ssl:"true"===process.env.DATABASE_SSL}),[r]=await e.execute(`
      SELECT title, excerpt, content, created_at, slug 
      FROM blog_posts 
      WHERE published = 1 
      ORDER BY created_at DESC 
      LIMIT 10
    `);await e.end();let n=process.env.NEXT_PUBLIC_BASE_URL,s=`<?xml version="1.0" encoding="UTF-8" ?>
<rss version="2.0">
  <channel>
    <title>Your Blog Name</title>
    <link>${n}</link>
    <description>Your blog description</description>
    <language>en-us</language>
    ${r.map(e=>`
      <item>
        <title>${l(e.title)}</title>
        <link>${n}/blog/${e.slug}</link>
        <description>${l(e.excerpt)}</description>
        <pubDate>${new Date(e.created_at).toUTCString()}</pubDate>
        <guid>${n}/blog/${e.slug}</guid>
      </item>
    `).join("")}
  </channel>
</rss>`;t.setHeader("Content-Type","application/xml"),t.write(s),t.end()}catch(e){console.error("Error generating RSS feed:",e),t.status(500).json({message:"Internal server error"})}}function l(e){return e.replace(/[<>&'"]/g,e=>{switch(e){case"<":return"&lt;";case">":return"&gt;";case"&":return"&amp;";case"'":return"&apos;";case'"':return"&quot;"}})}let p=(0,o.M)(n,"default"),d=(0,o.M)(n,"config"),g=new s.PagesAPIRouteModule({definition:{kind:i.A.PAGES_API,page:"/api/rss",pathname:"/api/rss",bundlePath:"",filename:""},userland:n})},2706:(e,t)=>{Object.defineProperty(t,"A",{enumerable:!0,get:function(){return r}});var r=function(e){return e.PAGES="PAGES",e.PAGES_API="PAGES_API",e.APP_PAGE="APP_PAGE",e.APP_ROUTE="APP_ROUTE",e.IMAGE="IMAGE",e}({})},9947:(e,t,r)=>{e.exports=r(5600)}};var t=require("../../webpack-api-runtime.js");t.C(e);var r=t(t.s=7722);module.exports=r})();